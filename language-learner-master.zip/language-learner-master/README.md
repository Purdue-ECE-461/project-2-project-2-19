# My First Experience w/ React
A language learner that is more curtailed to how I think languages should be learned.
<br> <br> <br>
https://language-learner-us.web.app
<br>

### `npm run dev` or `firebase serve`

Runs the app in the development mode.

